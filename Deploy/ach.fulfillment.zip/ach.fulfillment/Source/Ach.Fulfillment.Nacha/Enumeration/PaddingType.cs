﻿namespace Ach.Fulfillment.Nacha.Enumeration
{
    public enum PaddingType
    {
        Default,
        ZeroPadRight,
        ZeroPadLeft,
        SpacePadRight,
        SpacePadLeft,
        CustomPadRight,
        CustomPadLeft,
    }
}
