﻿namespace Ach.Fulfillment.Nacha.Enumeration
{
    public enum ServiceClassCode
    { 
        CreditOnly = 220,
        DebitOnly = 225,
        CreditAndDebit = 220,
    }
}
