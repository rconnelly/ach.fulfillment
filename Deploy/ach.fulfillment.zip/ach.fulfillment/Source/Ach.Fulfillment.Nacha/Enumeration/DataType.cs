﻿namespace Ach.Fulfillment.Nacha.Enumeration
{
    public enum DataType
    {
        Numeric,
        Alphanumeric,
        Date,
    }
}
