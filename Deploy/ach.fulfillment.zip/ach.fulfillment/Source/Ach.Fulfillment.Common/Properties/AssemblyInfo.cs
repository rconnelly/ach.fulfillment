﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ach.Fulfillment.Common")]
[assembly: AssemblyDescription("")]
[assembly: Guid("f946b512-d498-43f6-9a26-371b5b04aae6")]
