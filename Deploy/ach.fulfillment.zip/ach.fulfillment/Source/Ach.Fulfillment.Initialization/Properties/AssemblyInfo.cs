﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ach.Fulfillment.Initialization")]
[assembly: AssemblyDescription("")]
[assembly: Guid("94112702-ced5-4175-b7bf-ac93d4ab3a6d")]
