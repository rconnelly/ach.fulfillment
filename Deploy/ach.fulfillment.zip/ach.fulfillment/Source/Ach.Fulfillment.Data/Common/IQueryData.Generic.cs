namespace Ach.Fulfillment.Data.Common
{
    public interface IQueryData<T> : IQueryData
    {
    }
}