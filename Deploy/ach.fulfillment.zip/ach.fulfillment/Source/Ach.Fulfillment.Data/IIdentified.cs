namespace Ach.Fulfillment.Data
{
    public interface IIdentified
    {
        long Id { get; }
    }
}