﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ach.Fulfillment.Data")]
[assembly: AssemblyDescription("")]
[assembly: Guid("0c8825d5-1a11-496c-b5d4-e64f762be0a9")]