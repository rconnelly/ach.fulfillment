namespace Ach.Fulfillment.Data
{
    public interface IEntity : IAuditable, IIdentified
    {
    }
}