﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ach.Fulfillment.Business")]
[assembly: AssemblyDescription("")]
[assembly: Guid("5d2959ea-bae8-48e8-8860-d0fa7821b172")]