﻿namespace Ach.Fulfillment.Shared.Reflection
{
    public interface IReflectAttribute
    {
        int Position { get; set; }
    }
}
