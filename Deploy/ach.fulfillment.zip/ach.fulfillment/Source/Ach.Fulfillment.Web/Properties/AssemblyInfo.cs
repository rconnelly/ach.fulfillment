﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ach.Fulfillment.Web")]
[assembly: AssemblyDescription("")]
[assembly: Guid("1504e8f5-4ea8-4243-a7c3-5b394a3d5ddf")]
