﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ach.Fulfillment.Persistence")]
[assembly: AssemblyDescription("")]
[assembly: Guid("3d5ff4e8-d697-4161-b04a-724a5cfbb8ff")]