﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ach.Fulfillment.Migrations")]
[assembly: AssemblyDescription("")]
[assembly: Guid("04bfffe4-c8c5-45c6-bc2d-5c9662a444fb")]
