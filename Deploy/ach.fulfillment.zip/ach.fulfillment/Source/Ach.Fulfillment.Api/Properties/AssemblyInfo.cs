﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Ach.Fulfillment.Api")]
[assembly: AssemblyDescription("")]
[assembly: Guid("48ef7493-2e48-4776-8b43-e492d567d417")]